/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Administrator
 */
@Entity
@Table(name = "deliverdetail")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Deliverdetail.findAll", query = "SELECT d FROM Deliverdetail d"),
    @NamedQuery(name = "Deliverdetail.findByCodeNumber", query = "SELECT d FROM Deliverdetail d WHERE d.codeNumber = :codeNumber"),
    @NamedQuery(name = "Deliverdetail.findByCustomerReceiver", query = "SELECT d FROM Deliverdetail d WHERE d.customerReceiver = :customerReceiver"),
    @NamedQuery(name = "Deliverdetail.findByCustomerName", query = "SELECT d FROM Deliverdetail d WHERE d.customerName = :customerName"),
    @NamedQuery(name = "Deliverdetail.findByCustomerAdderss", query = "SELECT d FROM Deliverdetail d WHERE d.customerAdderss = :customerAdderss")})
public class Deliverdetail implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 40)
    @Column(name = "Code_Number")
    private String codeNumber;
    @Size(max = 40)
    @Column(name = "Customer_Receiver")
    private String customerReceiver;
    @Size(max = 40)
    @Column(name = "Customer_Name")
    private String customerName;
    @Size(max = 40)
    @Column(name = "Customer_Adderss")
    private String customerAdderss;
    @JoinColumn(name = "Code_Name", referencedColumnName = "Code_Name")
    @ManyToOne
    private Productdetail codeName;
    @JoinColumn(name = "S_Id", referencedColumnName = "S_Id")
    @ManyToOne
    private Sender sId;

    public Deliverdetail() {
    }

    public Deliverdetail(String codeNumber) {
        this.codeNumber = codeNumber;
    }

    public String getCodeNumber() {
        return codeNumber;
    }

    public void setCodeNumber(String codeNumber) {
        this.codeNumber = codeNumber;
    }

    public String getCustomerReceiver() {
        return customerReceiver;
    }

    public void setCustomerReceiver(String customerReceiver) {
        this.customerReceiver = customerReceiver;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerAdderss() {
        return customerAdderss;
    }

    public void setCustomerAdderss(String customerAdderss) {
        this.customerAdderss = customerAdderss;
    }

    public Productdetail getCodeName() {
        return codeName;
    }

    public void setCodeName(Productdetail codeName) {
        this.codeName = codeName;
    }

    public Sender getSId() {
        return sId;
    }

    public void setSId(Sender sId) {
        this.sId = sId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codeNumber != null ? codeNumber.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Deliverdetail)) {
            return false;
        }
        Deliverdetail other = (Deliverdetail) object;
        if ((this.codeNumber == null && other.codeNumber != null) || (this.codeNumber != null && !this.codeNumber.equals(other.codeNumber))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "db.Deliverdetail[ codeNumber=" + codeNumber + " ]";
    }
    
}
